# Documentation
https://delivery.gfi.fr/confluence/display/GFIBT/Notify+Zabbix+of+EC2+termination
