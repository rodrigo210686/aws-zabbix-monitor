"""
Company: Inetum
Version: 1.0
Function: Notify Zabbix about instance terminated by ASG
Description: When an instance that belongs to ASG is terminate this function will notify the Zabbix to remove the entry.
             When an instance that belongs to ASG is terminate this function will notify the Zabbix to remove the entry.

            Lambda function has a timeout to finished. If the function not finish until this time it will be canceled and a log file will be created on S3 bucket.
Changelog:
    2021-05-10 : Creation
    
Copyright (C) 2021 Inetum. All rights reserved.
"""

from __future__ import print_function
from pyzabbix import ZabbixMetric, ZabbixSender
from datetime import datetime
import signal
import socket
import boto3
import json
import os

def lambda_handler(event, context):

    # Setup alarm for remaining runtime
    signal.alarm(int(context.get_remaining_time_in_millis() / 1000))

    message = event

    s3 = boto3.resource("s3")
    s3BucketName = os.environ['s3BucketName']
    s3Path = os.environ['s3FilePath']

    ZabbixHost = os.environ['ZabbixHost']
    zabbixPort = int(os.environ['zabbixPort'])
    zabbixTrapItem = os.environ['zabbixTrapItem']
    zabbixTimeout = int(os.environ['zabbixTimeout'])

    try:
        instance = event['detail']['EC2InstanceId']

        # Test if Zabbix is available
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(zabbixTimeout)
        connection = sock.connect_ex((ZabbixHost,int(zabbixPort)))
        if connection != 0:
            print('Timeout to connect to Zabbix')
            raise Exception('Timeout to connect to Zabbix')
        sock.close()

        # Send to Zabbix
        packet = [
            ZabbixMetric(instance, zabbixTrapItem, 1),
        ]
        
        result = ZabbixSender(ZabbixHost,zabbixPort,use_config=None,).send(packet)

        if int(result.failed) > 0:
            raise Exception('Zabbix did not accept the message.')
        
        print(instance)
        print(result)

    except Exception as erroMSG:
        print("Error to send to Zabbix")
        print(erroMSG)
        
        # Gerenate file name
        now = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        fileName = s3Path+'/error_'+now+'.txt'
        fileNameMessage = s3Path+'/error_message_'+now+'.txt'
        fileNameAlert = s3Path+'/alert_'+now+'.txt'
        
        # Save on S3
        s3.Bucket(s3BucketName).put_object(Key=fileName, Body=str(message))
        s3.Bucket(s3BucketName).put_object(Key=fileNameMessage, Body=str(erroMSG))
        s3.Bucket(s3BucketName).put_object(Key=fileNameAlert, Body=str(instance))

def timeout_handler(_signal, _frame):
    # If Lambda timeout is thrown the code below will be executed

    #import boto3
    s3 = boto3.resource("s3")
    s3BucketName = os.environ['s3BucketName']
    s3Path = os.environ['s3FilePath']
    
    # Gerenate file name
    now = datetime.now()
    fileNameMessage = s3Path+'/error_message_'+now.strftime("%Y%m%d_%H%M%S_%f")+'.txt'
    
    # Save on S3
    s3.Bucket(s3BucketName).put_object(Key=fileNameMessage, Body=str("Error - Lambda function timeout"))

signal.signal(signal.SIGALRM, timeout_handler)