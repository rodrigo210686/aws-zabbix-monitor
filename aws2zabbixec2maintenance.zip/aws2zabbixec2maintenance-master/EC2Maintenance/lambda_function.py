"""
Company: Inetum
Version: 1.0
Function: Manage maintenance window
Description: The goal of this function is enable or disable a maintenance window for EC2 instances.
             This function must be called with a JSON payload in the standard: {"body": { "instanceid": "<Instance Id>", "maintenance": "<RequiredAction>" }}
             The RequiredAction may be 1 to enable maintenance windows and 0 to disable.

Changelog:
    2021-09-20 : Creation
    
Copyright (C) 2021 Inetum. All rights reserved.
"""

from __future__ import print_function
from pyzabbix import ZabbixMetric, ZabbixSender
from datetime import datetime
import signal
import socket
import boto3
import json
import os

def lambda_handler(event, context):

    # Setup alarm for remaining runtime
    signal.alarm(int(context.get_remaining_time_in_millis() / 1000))

    message = event

    ZabbixHost = os.environ['ZabbixHost']
    zabbixPort = int(os.environ['zabbixPort'])
    zabbixTrapItem = os.environ['zabbixTrapItem']
    zabbixTimeout = int(os.environ['zabbixTimeout'])

    try:
        instance = event["body"]["instanceid"]

        if "maintenance" in event["body"]:
            action = event["body"]["maintenance"]
        else:
            action = 1

        # Test if Zabbix is available
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(zabbixTimeout)
        connection = sock.connect_ex((ZabbixHost,int(zabbixPort)))
        if connection != 0:
            print('Timeout to connect to Zabbix')
            raise Exception('Timeout to connect to Zabbix')
        sock.close()

        # Send to Zabbix
        packet = [
            ZabbixMetric(instance, zabbixTrapItem, action),
        ]
        
        result = ZabbixSender(ZabbixHost,zabbixPort,use_config=None,).send(packet)

        if int(result.failed) > 0:
            raise Exception('Zabbix did not accept the message.')
        
        print(instance)
        print(result)

        return 0

    except Exception as erroMSG:
        print("Error to send to Zabbix")
        print(erroMSG)

        return 999

def timeout_handler(_signal, _frame):
    # If Lambda timeout is thrown the code below will be executed
    print('Timeout to execute the function')

signal.signal(signal.SIGALRM, timeout_handler)