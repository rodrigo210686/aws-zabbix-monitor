# Documentation
https://delivery.gfi.fr/confluence/display/GFIBT/Manage+maintenance+window+to+EC2