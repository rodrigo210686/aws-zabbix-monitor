# Documentation
https://delivery.gfi.fr/confluence/display/GFIBT/Cloudwatch+alarms+to+Zabbix
